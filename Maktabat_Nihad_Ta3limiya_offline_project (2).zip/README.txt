Maktabat Nihad - Android offline project (Second Intermediate - 2nd grade)
=======================================================================
What's included:
- Full Android Studio project (module app/) with Java source code and XML layouts.
- app/src/main/assets/ contains placeholder files with the expected PDF filenames.
  You MUST replace these placeholder files with the real PDF files (same filenames) to make the app fully offline.
- The app shows lists of books and notes; when opening a book it loads the PDF from assets and allows next/prev page navigation.

Filenames to replace (place real PDFs here):
- arabic_part1.pdf (اللغة العربيه الجزء الاول) - 136 pages
- arabic_part2.pdf (اللغة العربيه الجزء الثاني) - 136 pages
- maths.pdf (الرياضيات) - 196 pages
- social.pdf (الاجتماعيات) - 140 pages
- bio.pdf (علم الاحياء) - 92 pages
- chem.pdf (الكيمياء) - 96 pages
- phys.pdf (الفيزياء) - 88 pages
- eng_activity.pdf (الانكليزي للنشاط) - 127 pages
- eng_color.pdf (الانكليزي الملون) - 120 pages
- computer_book.pdf (الحاسوب) - 144 pages
- islamic_book.pdf (التربيه الاسلامية) - 120 pages
- note_islam.pdf, note_arabic_p1.pdf, note_arabic_p2.pdf, note_eng.pdf, note_math.pdf, note_chem.pdf, note_phys.pdf, note_social.pdf

How to build (Android Studio):
1) Unzip the project and open the folder in Android Studio (Open project).
2) Wait for Gradle sync.
3) Replace placeholder files in app/src/main/assets/ with real PDFs (same filenames).
4) Run the app on emulator or device or Build -> Build APK(s).

How to build (command line):
- Install JDK (11+) and Android SDK, set ANDROID_HOME.
- In project root run:
    chmod +x ./gradlew
    ./gradlew assembleDebug
- Resulting APK: app/build/outputs/apk/debug/app-debug.apk

If you want, send me the PDF files and I will integrate them and return a ready APK.

© المطور: نهاد خالد
